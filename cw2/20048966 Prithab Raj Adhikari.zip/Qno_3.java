
/**
 * Write a description of class Qno_3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Qno_3
{
    public static void main(String[]args)
    {
     // Declare a string array and initialize
     String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" , "Saturday"};      
        
     // Displays the contents of each element
     for (String day : days)
     {
        System.out.println(day);
     }
    }
}
