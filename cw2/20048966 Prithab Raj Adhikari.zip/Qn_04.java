
/**
 * Write a description of class Qn_04 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.*;
public class Qn_04      
{  
    public static void main(String args[])  
    {  
    //first arraylist  
    ArrayList<String> firstList=new ArrayList<String>(Arrays.asList("Dog", "Cat", "Horse"));  
    System.out.println("First arraylist: "+ (firstList));  
    
    //second arraylist      
    List<String> secondList=new ArrayList<String>(Arrays.asList("Dog", "Panda"));  
    System.out.println("Second arraylist: "+ (secondList));  
    
    //returns the common elements in both list  
    secondList.retainAll(firstList);        
    System.out.println("Common elements in both list: "+ (secondList));  
}  
}  