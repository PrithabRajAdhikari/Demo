import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
  
class MyFrame
    extends JFrame
    implements ActionListener {

    private Container c;
    private JLabel title;
    private JLabel StudentID;
    private JTextField tStudentID;
    private JLabel FirstName;
    private JTextField tFirstName;
    private JLabel MiddleName;
    private JTextField tMiddleName;
    private JLabel LastName;
    private JTextField tLastName;
    private JLabel Age;
    private JTextField tAge;
    private JLabel Guardian;
    private JTextField tGuardian;
    private JLabel Relation;
    private JTextField tRelation;
    private JLabel CN;
    private JTextField tCN;
    private JLabel gender;
    private JRadioButton male;
    private JRadioButton female;
    private ButtonGroup gengp;
    private JLabel dob;
    private JComboBox date;
    private JComboBox month;
    private JComboBox year;
    private JLabel add;
    private JTextArea tadd;
    private JLabel add2;
    private JTextArea tadd2;
    private JLabel POB;
    private JTextArea tPOB;
    private JCheckBox term;
    private JLabel Schoolyear;
    private JComboBox SchoolYear;
     private JLabel SYear;
    private JComboBox Year;
    private JLabel Status;
    private JComboBox status;
    private JButton B1;
    private JButton B2;
    private JButton B3;
    private JButton B4;
    private JButton New;
    private JButton Save;
    private JLabel res;
    private JTextArea resadd;
    
    private String dates[]
        = { "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "10",
            "11", "12", "13", "14", "15",
            "16", "17", "18", "19", "20",
            "21", "22", "23", "24", "25",
            "26", "27", "28", "29", "30",
            "31" };
    private String months[]
        = { "Jan", "feb", "Mar", "Apr",
            "May", "Jun", "July", "Aug",
            "Sep", "Oct", "Nov", "Dec" };
    private String years[]
        = { "1995", "1996", "1997", "1998",
            "1999", "2000", "2001", "2002",
            "2003", "2004", "2005", "2006",
            "2007", "2008", "2009", "2010",
            "2011", "2012", "2013", "2014",
            "2015", "2016", "2017", "2018",
            "2019","2020","2021" };
            
    private String SchoolYears[]
        = {"2013-2015","2014-2016","2015-2017","2016-2018"};
        
     private String STATUS[]
     ={"Single","Taken"};
     
     private String Years[]
     ={"1st","2nd","3rd"};
  
    
    public MyFrame()
    {
        setTitle("Registration Form");
        setBounds(300, 90, 900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
  
        c = getContentPane();
        c.setLayout(null);
  
        title = new JLabel("Student's Registration Form");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(500, 30);
        title.setLocation(300, 30);
        c.add(title);
  
        StudentID = new JLabel("Student ID");
        StudentID.setFont(new Font("Arial", Font.PLAIN, 20));
        StudentID.setSize(100, 20);
        StudentID.setLocation(100, 100);
        c.add(StudentID);
  
        tStudentID = new JTextField();
        tStudentID.setFont(new Font("Arial", Font.PLAIN, 15));
        tStudentID.setSize(100, 20);
        tStudentID.setLocation(200, 100);
        c.add(tStudentID);
        
        FirstName = new JLabel("First Name");
        FirstName.setFont(new Font("Arial", Font.PLAIN, 20));
        FirstName.setSize(100, 20);
        FirstName.setLocation(100, 150);
        c.add(FirstName);
  
        tFirstName = new JTextField();
        tFirstName.setFont(new Font("Arial", Font.PLAIN, 15));
        tFirstName.setSize(100, 20);
        tFirstName.setLocation(200, 150);
        c.add(tFirstName);
        
        MiddleName = new JLabel("Middle Name");
        MiddleName.setFont(new Font("Arial", Font.PLAIN, 20));
        MiddleName.setSize(200, 20);
        MiddleName.setLocation(350, 150);
        c.add(MiddleName);
  
        tMiddleName = new JTextField();
        tMiddleName.setFont(new Font("Arial", Font.PLAIN, 15));
        tMiddleName.setSize(100, 20);
        tMiddleName.setLocation(480, 150);
        c.add(tMiddleName);
        
        LastName = new JLabel("Last Name");
        LastName.setFont(new Font("Arial", Font.PLAIN, 20));
        LastName.setSize(100, 20);
        LastName.setLocation(600, 150);
        c.add(LastName);
  
        tLastName = new JTextField();
        tLastName.setFont(new Font("Arial", Font.PLAIN, 15));
        tLastName.setSize(100, 20);
        tLastName.setLocation(700, 150);
        c.add(tLastName);
  
  
        CN = new JLabel("Contact Number");
        CN.setFont(new Font("Arial", Font.PLAIN, 20));
        CN.setSize(150, 20);
        CN.setLocation(550,360);
        c.add(CN);
  
        tCN = new JTextField();
        tCN.setFont(new Font("Arial", Font.PLAIN, 15));
        tCN.setSize(150, 20);
        tCN.setLocation(700, 360);
        c.add(tCN);
        
        add2 = new JLabel("Address");
        add2.setFont(new Font("Arial", Font.PLAIN, 20));
        add2.setSize(100, 20);
        add2.setLocation(100, 360);
        c.add(add2);
  
        tadd2 = new JTextArea();
        tadd2.setFont(new Font("Arial", Font.PLAIN, 15));
        tadd2.setSize(120, 40);
        tadd2.setLocation(200, 360);
        tadd2.setLineWrap(true);
        c.add(tadd2);
        
        Age = new JLabel("Age");
        Age.setFont(new Font("Arial", Font.PLAIN, 20));
        Age.setSize(100, 20);
        Age.setLocation(100, 260);
        c.add(Age);
  
        tAge = new JTextField();
        tAge.setFont(new Font("Arial", Font.PLAIN, 15));
        tAge.setSize(100, 20);
        tAge.setLocation(200, 260);
        c.add(tAge);
  
        gender = new JLabel("Gender");
        gender.setFont(new Font("Arial", Font.PLAIN, 20));
        gender.setSize(100, 20);
        gender.setLocation(350, 260);
        c.add(gender);
  
        male = new JRadioButton("Male");
        male.setFont(new Font("Arial", Font.PLAIN, 15));
        male.setSelected(true);
        male.setSize(60, 20);
        male.setLocation(450, 260);
        c.add(male);
  
        female = new JRadioButton("Female");
        female.setFont(new Font("Arial", Font.PLAIN, 15));
        female.setSelected(false);
        female.setSize(80, 20);
        female.setLocation(510, 260);
        c.add(female);
  
        gengp = new ButtonGroup();
        gengp.add(male);
        gengp.add(female);
  
        dob = new JLabel("DOB");
        dob.setFont(new Font("Arial", Font.PLAIN, 20));
        dob.setSize(100, 20);
        dob.setLocation(350, 200);
        c.add(dob);
  
        date = new JComboBox(dates);
        date.setFont(new Font("Arial", Font.PLAIN, 15));
        date.setSize(60, 20);
        date.setLocation(400, 200);
        c.add(date);
  
        month = new JComboBox(months);
        month.setFont(new Font("Arial", Font.PLAIN, 15));
        month.setSize(60, 20);
        month.setLocation(450, 200);
        c.add(month);
  
        year = new JComboBox(years);
        year.setFont(new Font("Arial", Font.PLAIN, 15));
        year.setSize(60, 20);
        year.setLocation(500, 200);
        c.add(year);
        
        Schoolyear = new JLabel("School Year");
        Schoolyear.setFont(new Font("Arial", Font.PLAIN, 20));
        Schoolyear.setSize(500, 20);
        Schoolyear.setLocation(600, 100);
        c.add(Schoolyear);
        
        
        SchoolYear = new JComboBox(SchoolYears);
        SchoolYear.setFont(new Font("Arial", Font.PLAIN, 15));
        SchoolYear.setSize(100, 20);
        SchoolYear.setLocation(720, 100);
        c.add(SchoolYear);
        
        SYear = new JLabel("SYear");
        SYear.setFont(new Font("Arial", Font.PLAIN, 20));
        SYear.setSize(500, 20);
        SYear.setLocation(100, 300);
        c.add(SYear);
        
        Year = new JComboBox(Years);
        Year.setFont(new Font("Arial", Font.PLAIN, 15));
        Year.setSize(100, 20);
        Year.setLocation(200, 300);
        c.add(Year);
        
        Status = new JLabel("Status");
        Status.setFont(new Font("Arial", Font.PLAIN, 20));
        Status.setSize(500, 20);
        Status.setLocation(600, 260);
        c.add(Status);
        
        
        status = new JComboBox(STATUS);
        status.setFont(new Font("Arial", Font.PLAIN, 15));
        status.setSize(100, 20);
        status.setLocation(700, 260);
        c.add(status);
  
        add = new JLabel("Address");
        add.setFont(new Font("Arial", Font.PLAIN, 20));
        add.setSize(100, 20);
        add.setLocation(100, 200);
        c.add(add);
  
        tadd = new JTextArea();
        tadd.setFont(new Font("Arial", Font.PLAIN, 15));
        tadd.setSize(120, 40);
        tadd.setLocation(200, 200);
        tadd.setLineWrap(true);
        c.add(tadd);
        
        
        POB = new JLabel("Place Of Birth");
        POB.setFont(new Font("Arial", Font.PLAIN, 20));
        POB.setSize(150, 20);
        POB.setLocation(600, 200);
        c.add(POB);
  
        tPOB = new JTextArea();
        tPOB.setFont(new Font("Arial", Font.PLAIN, 15));
        tPOB.setSize(120, 40);
        tPOB.setLocation(730, 200);
        tPOB.setLineWrap(true);
        c.add(tPOB);
        
        
        Guardian = new JLabel("Guardian");
        Guardian.setFont(new Font("Arial", Font.PLAIN, 20));
        Guardian.setSize(100, 20);
        Guardian.setLocation(350, 300);
        c.add(Guardian);
  
        tGuardian = new JTextField();
        tGuardian.setFont(new Font("Arial", Font.PLAIN, 15));
        tGuardian.setSize(100, 20);
        tGuardian.setLocation(450, 300);
        c.add(tGuardian);
        
        Relation = new JLabel("Relation");
        Relation.setFont(new Font("Arial", Font.PLAIN, 20));
        Relation.setSize(100, 20);
        Relation.setLocation(600, 300);
        c.add(Relation);
  
        tRelation = new JTextField();
        tRelation.setFont(new Font("Arial", Font.PLAIN, 15));
        tRelation.setSize(100, 20);
        tRelation.setLocation(700, 300);
        c.add(tRelation);
        
        

        term = new JCheckBox("Are you ready to rumble.");
        term.setFont(new Font("Arial", Font.PLAIN, 15));
        term.setSize(250, 20);
        term.setLocation(400, 420);
        c.add(term);
        
        B1= new JButton("|<");
        B1.setFont(new Font("Arial", Font.PLAIN, 15));
        B1.setSize(100, 20);
        B1.setLocation(100, 450);
        B1.addActionListener(this);
        c.add(B1);
        
        
        B2= new JButton("<<");
        B2.setFont(new Font("Arial", Font.PLAIN, 15));
        B2.setSize(100, 20);
        B2.setLocation(200, 450);
        B2.addActionListener(this);
        c.add(B2);
        
        
        B3= new JButton(">>");
        B3.setFont(new Font("Arial", Font.PLAIN, 15));
        B3.setSize(100, 20);
        B3.setLocation(300, 450);
        B3.addActionListener(this);
        c.add(B3);
        
        
        B4= new JButton(">|");
        B4.setFont(new Font("Arial", Font.PLAIN, 15));
        B4.setSize(100, 20);
        B4.setLocation(400, 450);
        B4.addActionListener(this);
        c.add(B4);
  
  
        Save= new JButton("Save");
        Save.setFont(new Font("Arial", Font.PLAIN, 15));
        Save.setSize(100, 20);
        Save.setLocation(600, 450);
        Save.addActionListener(this);
        c.add(Save);
  
        New = new JButton("New");
        New.setFont(new Font("Arial", Font.PLAIN, 15));
        New.setSize(100, 20);
        New.setLocation(700, 450);
        New.addActionListener(this);
        c.add(New);
        
        
        res = new JLabel("");
        res.setFont(new Font("Arial", Font.PLAIN, 20));
        res.setSize(500, 25);
        res.setLocation(100, 500);
        c.add(res);
  
  
        setVisible(true);
    }
  
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == Save) {
            if (term.isSelected()) {
                String data1;
                String data
                    = "Name : "
                      + tStudentID.getText() + "\n"
                      + "Contact Number : "
                      + tCN.getText() + "\n";
                if (male.isSelected())
                    data1 = "Gender : Male"
                            + "\n";
                else
                    data1 = "Gender : Female"
                            + "\n";
                String data2
                    = "DOB : "
                      + (String)date.getSelectedItem()
                      + "/" + (String)month.getSelectedItem()
                      + "/" + (String)year.getSelectedItem()
                      + "\n";
  
                String data3 = "Address : " + tadd.getText();
                
                String data4= "Schoolyear:"
                + (String)SchoolYear.getSelectedItem() + "\n";
                
                String data5= "Status:"
                + (String)status.getSelectedItem() + "\n";
                
                res.setText("Registration Successful..");
            }
        }
  
        else if (e.getSource() == New) {
            String def = "";
            tStudentID.setText(def);
            tadd.setText(def);
            tadd2.setText(def);
            tCN.setText(def);
            term.setSelected(false);
            date.setSelectedIndex(0);
            month.setSelectedIndex(0);
            year.setSelectedIndex(0);
            SchoolYear.setSelectedIndex(0);
            status.setSelectedIndex(0);
            year.setSelectedIndex(0);
            resadd.setText(def);
        }
    }
}
 